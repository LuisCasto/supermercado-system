--
-- PostgreSQL database dump
--

\restrict pb0uB10Kc1XWiqwj447xrtrOX2YCGpn19c1nfnVaYgfDC8EyVaNPZaZKKkPTR7P

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.product_batches DROP CONSTRAINT IF EXISTS product_batches_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.inventory_movements DROP CONSTRAINT IF EXISTS inventory_movements_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.inventory_movements DROP CONSTRAINT IF EXISTS inventory_movements_product_batch_id_fkey;
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
DROP TRIGGER IF EXISTS update_products_updated_at ON public.products;
DROP INDEX IF EXISTS public.idx_users_username;
DROP INDEX IF EXISTS public.idx_users_role;
DROP INDEX IF EXISTS public.idx_products_sku;
DROP INDEX IF EXISTS public.idx_products_name;
DROP INDEX IF EXISTS public.idx_products_category;
DROP INDEX IF EXISTS public.idx_outbox_status_created;
DROP INDEX IF EXISTS public.idx_outbox_aggregate;
DROP INDEX IF EXISTS public.idx_movements_user;
DROP INDEX IF EXISTS public.idx_movements_created;
DROP INDEX IF EXISTS public.idx_movements_batch;
DROP INDEX IF EXISTS public.idx_batches_product_id;
DROP INDEX IF EXISTS public.idx_batches_expiration;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_sku_key;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.product_batches DROP CONSTRAINT IF EXISTS product_batches_product_id_batch_code_key;
ALTER TABLE IF EXISTS ONLY public.product_batches DROP CONSTRAINT IF EXISTS product_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.outbox_events DROP CONSTRAINT IF EXISTS outbox_events_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_movements DROP CONSTRAINT IF EXISTS inventory_movements_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_batches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.outbox_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.inventory_movements ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.products_id_seq;
DROP TABLE IF EXISTS public.products;
DROP SEQUENCE IF EXISTS public.product_batches_id_seq;
DROP TABLE IF EXISTS public.product_batches;
DROP SEQUENCE IF EXISTS public.outbox_events_id_seq;
DROP TABLE IF EXISTS public.outbox_events;
DROP SEQUENCE IF EXISTS public.inventory_movements_id_seq;
DROP TABLE IF EXISTS public.inventory_movements;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: inventory_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements (
    id integer NOT NULL,
    product_batch_id integer NOT NULL,
    movement_type character varying(20) NOT NULL,
    quantity integer NOT NULL,
    user_id integer NOT NULL,
    reference_id character varying(100),
    note text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT inventory_movements_movement_type_check CHECK (((movement_type)::text = ANY ((ARRAY['ENTRY'::character varying, 'SALE'::character varying, 'ADJUSTMENT'::character varying, 'EXPIRATION'::character varying])::text[])))
);


--
-- Name: TABLE inventory_movements; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.inventory_movements IS 'Auditoría de movimientos de inventario';


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_movements_id_seq OWNED BY public.inventory_movements.id;


--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbox_events (
    id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    aggregate_id character varying(100) NOT NULL,
    payload jsonb NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    retry_count integer DEFAULT 0,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp without time zone,
    CONSTRAINT outbox_events_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'PROCESSING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying])::text[])))
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.outbox_events IS 'Patrón Outbox para consistencia eventual';


--
-- Name: outbox_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.outbox_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: outbox_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.outbox_events_id_seq OWNED BY public.outbox_events.id;


--
-- Name: product_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_batches (
    id integer NOT NULL,
    product_id integer NOT NULL,
    batch_code character varying(100) NOT NULL,
    quantity integer NOT NULL,
    cost_per_unit numeric(10,2) NOT NULL,
    expiration_date date,
    received_date date DEFAULT CURRENT_DATE NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT product_batches_cost_per_unit_check CHECK ((cost_per_unit > (0)::numeric)),
    CONSTRAINT product_batches_quantity_check CHECK ((quantity >= 0))
);


--
-- Name: TABLE product_batches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_batches IS 'Lotes de productos con fechas de vencimiento';


--
-- Name: product_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_batches_id_seq OWNED BY public.product_batches.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    sku character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    category character varying(100),
    base_price numeric(10,2) NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT products_base_price_check CHECK ((base_price > (0)::numeric))
);


--
-- Name: TABLE products; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.products IS 'Catálogo de productos del supermercado';


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['gerente'::character varying, 'inventario'::character varying, 'cajero'::character varying])::text[])))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.users IS 'Usuarios del sistema con roles RBAC';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: inventory_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements ALTER COLUMN id SET DEFAULT nextval('public.inventory_movements_id_seq'::regclass);


--
-- Name: outbox_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox_events ALTER COLUMN id SET DEFAULT nextval('public.outbox_events_id_seq'::regclass);


--
-- Name: product_batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_batches ALTER COLUMN id SET DEFAULT nextval('public.product_batches_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: inventory_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_movements (id, product_batch_id, movement_type, quantity, user_id, reference_id, note, created_at) FROM stdin;
1	1	ENTRY	100	2	\N	Recepción de mercancía - Proveedor A	2025-12-03 05:28:12.963372
2	2	ENTRY	50	2	\N	Recepción de mercancía - Proveedor A	2025-12-03 05:28:12.963372
3	3	ENTRY	80	2	\N	Recepción de mercancía - Proveedor B	2025-12-03 05:28:12.963372
4	4	ENTRY	200	2	\N	Recepción de mercancía - Panadería Local	2025-12-03 05:28:12.963372
5	5	ENTRY	300	2	\N	Recepción de mercancía - Embotelladora	2025-12-03 05:28:12.963372
6	6	ENTRY	150	2	\N	Recepción de mercancía - Distribuidora	2025-12-03 05:28:12.963372
7	7	ENTRY	50	2	\N	Recepción de mercancía - Mercado Local	2025-12-03 05:28:12.963372
8	8	ENTRY	40	2	\N	Recepción de mercancía - Mercado Local	2025-12-03 05:28:12.963372
9	9	ENTRY	30	2	\N	Recepción de mercancía - Carnicería Central	2025-12-03 05:28:12.963372
10	1	SALE	-2	1	SALE-20251203-030119-918672	Venta SALE-20251203-030119-918672	2025-12-03 09:01:19.433659
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outbox_events (id, event_type, aggregate_id, payload, status, retry_count, error_message, created_at, processed_at) FROM stdin;
1	SALE_CREATED	SALE-20251203-030119-918672	{"tax": 8.16, "items": [{"sku": "LAC-001", "quantity": 2, "subtotal": 51.0, "product_id": 1, "unit_price": 25.5, "product_name": "Leche Entera 1L"}], "total": 51.0, "status": "completed", "sale_id": "SALE-20251203-030119-918672", "timestamp": "2025-12-03T09:01:19.485200", "cashier_id": 1, "grand_total": 59.16, "cashier_name": "gerente1", "payment_method": "cash", "payment_details": {}}	COMPLETED	0	\N	2025-12-03 09:01:19.433659	2025-12-03 09:01:20.187368
\.


--
-- Data for Name: product_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_batches (id, product_id, batch_code, quantity, cost_per_unit, expiration_date, received_date, created_at) FROM stdin;
2	1	LOTE-LAC-2025-02	50	18.50	2025-12-20	2025-11-25	2025-12-03 05:28:12.95531
3	2	LOTE-YOG-2025-01	80	32.00	2025-12-10	2025-11-18	2025-12-03 05:28:12.95531
4	3	LOTE-PAN-2025-01	200	12.00	2025-11-30	2025-11-28	2025-12-03 05:28:12.95531
5	4	LOTE-AGU-2025-01	300	8.00	2026-06-01	2025-11-01	2025-12-03 05:28:12.95531
6	5	LOTE-REF-2025-01	150	20.00	2026-03-01	2025-11-15	2025-12-03 05:28:12.95531
7	6	LOTE-FRU-2025-01	50	25.00	2025-12-05	2025-11-27	2025-12-03 05:28:12.95531
8	7	LOTE-VER-2025-01	40	15.00	2025-12-01	2025-11-27	2025-12-03 05:28:12.95531
9	8	LOTE-CAR-2025-01	30	95.00	2025-12-03	2025-11-26	2025-12-03 05:28:12.95531
1	1	LOTE-LAC-2025-01	98	18.00	2025-12-15	2025-11-20	2025-12-03 05:28:12.95531
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, sku, name, description, category, base_price, active, created_at, updated_at) FROM stdin;
1	LAC-001	Leche Entera 1L	Leche entera pasteurizada	Lácteos	25.50	t	2025-12-03 05:28:12.947435	2025-12-03 05:28:12.947435
2	LAC-002	Yogurt Natural 1kg	Yogurt natural sin azúcar	Lácteos	45.00	t	2025-12-03 05:28:12.947435	2025-12-03 05:28:12.947435
3	PAN-010	Pan Blanco	Pan blanco tradicional	Panadería	18.00	t	2025-12-03 05:28:12.947435	2025-12-03 05:28:12.947435
4	BEB-001	Agua Natural 1.5L	Agua purificada	Bebidas	12.00	t	2025-12-03 05:28:12.947435	2025-12-03 05:28:12.947435
5	BEB-002	Refresco Cola 2L	Bebida carbonatada	Bebidas	28.00	t	2025-12-03 05:28:12.947435	2025-12-03 05:28:12.947435
6	FRU-001	Manzana Red Delicious kg	Manzana fresca	Frutas	35.00	t	2025-12-03 05:28:12.947435	2025-12-03 05:28:12.947435
7	VER-001	Lechuga Romana	Lechuga fresca	Verduras	22.00	t	2025-12-03 05:28:12.947435	2025-12-03 05:28:12.947435
8	CAR-001	Carne Molida kg	Carne de res molida	Carnicería	120.00	t	2025-12-03 05:28:12.947435	2025-12-03 05:28:12.947435
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, hashed_password, role, active, created_at, updated_at) FROM stdin;
1	gerente1	gerente@supermercado.com	$2b$12$AnehbzfVpf1otpAHlI6bh.SMG5Webavps1u.d.bCwwVZTAbPoL7mq	gerente	t	2025-12-03 05:28:12.942853	2025-12-03 05:28:12.942853
2	inventario1	inventario@supermercado.com	$2b$12$AnehbzfVpf1otpAHlI6bh.SMG5Webavps1u.d.bCwwVZTAbPoL7mq	inventario	t	2025-12-03 05:28:12.942853	2025-12-03 05:28:12.942853
3	cajero1	cajero1@supermercado.com	$2b$12$AnehbzfVpf1otpAHlI6bh.SMG5Webavps1u.d.bCwwVZTAbPoL7mq	cajero	t	2025-12-03 05:28:12.942853	2025-12-03 05:28:12.942853
4	cajero2	cajero2@supermercado.com	$2b$12$AnehbzfVpf1otpAHlI6bh.SMG5Webavps1u.d.bCwwVZTAbPoL7mq	cajero	t	2025-12-03 05:28:12.942853	2025-12-03 05:28:12.942853
\.


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_movements_id_seq', 10, true);


--
-- Name: outbox_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.outbox_events_id_seq', 1, true);


--
-- Name: product_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_batches_id_seq', 9, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 8, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: inventory_movements inventory_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: product_batches product_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_batches
    ADD CONSTRAINT product_batches_pkey PRIMARY KEY (id);


--
-- Name: product_batches product_batches_product_id_batch_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_batches
    ADD CONSTRAINT product_batches_product_id_batch_code_key UNIQUE (product_id, batch_code);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_sku_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_key UNIQUE (sku);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_batches_expiration; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_batches_expiration ON public.product_batches USING btree (expiration_date);


--
-- Name: idx_batches_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_batches_product_id ON public.product_batches USING btree (product_id);


--
-- Name: idx_movements_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_movements_batch ON public.inventory_movements USING btree (product_batch_id);


--
-- Name: idx_movements_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_movements_created ON public.inventory_movements USING btree (created_at);


--
-- Name: idx_movements_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_movements_user ON public.inventory_movements USING btree (user_id);


--
-- Name: idx_outbox_aggregate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_outbox_aggregate ON public.outbox_events USING btree (aggregate_id);


--
-- Name: idx_outbox_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_outbox_status_created ON public.outbox_events USING btree (status, created_at);


--
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_category ON public.products USING btree (category);


--
-- Name: idx_products_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_name ON public.products USING btree (name);


--
-- Name: idx_products_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_sku ON public.products USING btree (sku);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: products update_products_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: inventory_movements inventory_movements_product_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_product_batch_id_fkey FOREIGN KEY (product_batch_id) REFERENCES public.product_batches(id) ON DELETE CASCADE;


--
-- Name: inventory_movements inventory_movements_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: product_batches product_batches_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_batches
    ADD CONSTRAINT product_batches_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict pb0uB10Kc1XWiqwj447xrtrOX2YCGpn19c1nfnVaYgfDC8EyVaNPZaZKKkPTR7P

